# Twitter Crisis-Signal Analysis (Early COVID-19 Pandemic)

This repository contains an extended, research-grade Python pipeline for analyzing aggregate crisis signals in Twitter data from **March 25, 2020** through **September 15, 2020**.

The pipeline focuses on temporal distress dynamics, sentiment shifts, and rumor amplification at a macro-scale. It utilizes advanced NLP techniques including BERTweet embeddings and LSTM Autoencoders to identify distinct phases of the crisis.

## Features

- **Dual-Track Preprocessing**: Separate cleaning paths for lexicon-based analysis (VADER, NRC) and LLM-based analysis (BERTweet).
- **Sentiment & Distress Scoring**: Comprehensive 3-class sentiment labeling and NRC-style emotion distress metrics.
- **BERTweet Integration**: Generation of 768-D contextual embeddings with automated caching.
- **Deep Learning Architecture**: LSTM Autoencoder for identifying latent temporal structures.
- **Algorithmic Segmentation**: Changepoint detection (PELT) and KMeans clustering on bottleneck hidden states.
- **Research Dashboard**: automated 6-panel visualization for publication-ready findings.

## Repository Structure

```text
.
├── src/               # Core analytical modules
├── notebooks/         # Orchestration notebooks
├── configs/           # Study constants & keyword lists
├── data/              # Multi-stage data (Raw, Hydrated, Processed)
├── embeddings/        # Cached chunked embeddings
├── checkpoints/       # Model weights
├── reports/           # Visual and quantitative metrics
└── requirements.txt   # Dependencies
```

## Setup & Usage

1.  **Clone the Repository**:
    ```bash
    git clone <repository-url>
    cd <repository-name>
    ```
2.  **Install Requirements**:
    ```bash
    pip install -r requirements.txt
    ```
3.  **Configure API Tokens**: 
    Create a `.env` file in the root directory and add your Twitter Bearer Token:
    ```text
    TWITTER_BEARER_TOKEN=your_token_here
    ```
4.  **Run the Pipeline**:
    Execute the orchestration notebook located at `notebooks/run_pipeline.ipynb`.

## Research Integrity & Constraints

- **Macro-level Analysis**: This project is strictly for aggregate study (e.g., population-level sentiment).
- **No Individual Profiling**: The pipeline does not build user-level profiles or diagnose individuals.
- **Reproducibility**: All seeds, hyperparameters, and splits are fixed for scientific consistency.

## License

[MIT License](LICENSE)
